import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class wordcounter extends JFrame {
    private JLabel resultLabel;
    private JTextField paragraphField;
    private JButton countButton;

    public wordcounter() {
        setTitle("Word Counter");
        setSize(400, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));

        paragraphField = new JTextField();
        resultLabel = new JLabel("Number of words: 0");
        countButton = new JButton("Count Words");

        countButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String paragraph = paragraphField.getText();
                int wordCount = countWords(paragraph);
                resultLabel.setText("Number of words: " + wordCount);
            }
        });

        mainPanel.add(paragraphField);
        mainPanel.add(countButton);
        mainPanel.add(resultLabel);

        add(mainPanel);
    }

    private int countWords(String paragraph) {
        if (paragraph == null || paragraph.isEmpty()) {
            return 0;
        }

        String[] words = paragraph.split("\\s+");
        return words.length;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new wordcounter().setVisible(true);
            }
        });
    }
}